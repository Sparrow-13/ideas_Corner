# ideas_Corner
this is project is about  creating a site that give you an idea to where you should learn specific skill or topics

the project structure is as follows :
it contains main html directory
html contains a homepage.html  ,css folder,js folder, assets folder, a content_pages folder
content_pages contains the pages of content used in site with topic name as file name.
